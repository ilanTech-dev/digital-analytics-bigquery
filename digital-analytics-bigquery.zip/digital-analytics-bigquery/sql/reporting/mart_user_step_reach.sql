/*
Model: mart_user_step_reach

Grain:
- One row per event date, dimensional combination, user and funnel step.

Interpretation:
- Step reach, not strict ordered progression.
*/

CREATE OR REPLACE TABLE
  `your-gcp-project.analytics_portfolio.mart_user_step_reach`

CLUSTER BY
  country,
  device_category,
  operating_system,
  new_returning_user

AS

WITH session_steps AS (
  SELECT
    session_date AS event_date,
    DATE_TRUNC(session_date, WEEK(MONDAY)) AS week_start,
    country,
    device_category,
    operating_system,
    new_returning_user,
    user_pseudo_id,

    [
      STRUCT(1 AS step_order, 'view_item' AS funnel_step, has_view_item AS reached_step),
      STRUCT(2 AS step_order, 'add_to_cart' AS funnel_step, has_add_to_cart AS reached_step),
      STRUCT(3 AS step_order, 'begin_checkout' AS funnel_step, has_begin_checkout AS reached_step),
      STRUCT(4 AS step_order, 'purchase' AS funnel_step, has_purchase AS reached_step)
    ] AS funnel_steps

  FROM
    `your-gcp-project.analytics_portfolio.int_sessions`
),

expanded_steps AS (
  SELECT
    event_date,
    week_start,
    country,
    device_category,
    operating_system,
    new_returning_user,
    user_pseudo_id,
    step.step_order,
    step.funnel_step

  FROM session_steps,
  UNNEST(funnel_steps) AS step

  WHERE step.reached_step
)

SELECT DISTINCT
  event_date,
  week_start,
  country,
  device_category,
  operating_system,
  new_returning_user,
  user_pseudo_id,
  step_order,
  funnel_step

FROM expanded_steps;
