/*
Model: mart_product_category_performance

Grain:
- One row per Monday-starting week and product category.

Metrics:
- Distinct purchasers
- Items sold
- Revenue placeholder (NULL because source is obfuscated)
- Top five selling products
*/

CREATE OR REPLACE TABLE
  `your-gcp-project.analytics_portfolio.mart_product_category_performance`

CLUSTER BY
  item_category

AS

WITH purchase_items AS (
  SELECT
    DATE_TRUNC(
      PARSE_DATE('%Y%m%d', event_date),
      WEEK(MONDAY)
    ) AS week_start,

    user_pseudo_id,
    item.item_category,
    item.item_name,
    item.quantity AS quantity,

    CAST(NULL AS NUMERIC) AS item_revenue_usd

  FROM
    `bigquery-public-data.ga4_obfuscated_sample_ecommerce.events_*`,
    UNNEST(items) AS item

  WHERE
    _TABLE_SUFFIX BETWEEN '20210101' AND '20210131'
    AND event_name = 'purchase'

    AND item.item_category IS NOT NULL
    AND TRIM(item.item_category) != ''
    AND item.item_category != '(not set)'

    AND item.item_name IS NOT NULL
    AND TRIM(item.item_name) != ''
    AND item.item_name != '(not set)'

    AND item.quantity IS NOT NULL
    AND item.quantity > 0
),

category_summary AS (
  SELECT
    week_start,
    item_category,
    COUNT(DISTINCT user_pseudo_id) AS total_purchasers,
    SUM(quantity) AS total_items_sold,
    CAST(NULL AS NUMERIC) AS total_revenue_usd

  FROM purchase_items
  GROUP BY week_start, item_category
),

product_summary AS (
  SELECT
    week_start,
    item_category,
    item_name,
    SUM(quantity) AS items_sold,
    CAST(NULL AS NUMERIC) AS revenue_usd

  FROM purchase_items
  GROUP BY week_start, item_category, item_name
),

top_products AS (
  SELECT
    week_start,
    item_category,

    ARRAY_AGG(
      STRUCT(
        item_name AS product_name,
        items_sold,
        revenue_usd
      )
      ORDER BY items_sold DESC, item_name
      LIMIT 5
    ) AS top_5_selling_products

  FROM product_summary
  GROUP BY week_start, item_category
)

SELECT
  category_summary.week_start,
  category_summary.item_category,
  category_summary.total_purchasers,
  category_summary.total_items_sold,
  category_summary.total_revenue_usd,
  top_products.top_5_selling_products

FROM category_summary
LEFT JOIN top_products
USING (week_start, item_category);
